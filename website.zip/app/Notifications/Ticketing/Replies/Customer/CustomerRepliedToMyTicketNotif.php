<?php

namespace App\Notifications\Ticketing\Replies\Customer;

use App\Notifications\Ticketing\Replies\NewReplyCreatedNotif;

class CustomerRepliedToMyTicketNotif extends NewReplyCreatedNotif
{
    public const NOTIF_ID = '05';
}
