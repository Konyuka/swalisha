<?php

namespace App\Notifications\Ticketing\Replies\Customer;

use App\Notifications\Ticketing\Replies\NewReplyCreatedNotif;

class CustomerRepliedToUnassignedTicketNotif extends NewReplyCreatedNotif
{
    public const NOTIF_ID = '04';
}
