<?php

namespace App\Notifications\Ticketing\Replies\Agent;

use App\Notifications\Ticketing\Replies\NewReplyCreatedNotif;

class AgentRepliedToMyTicketNotif extends NewReplyCreatedNotif
{
    public const NOTIF_ID = '08';
}
