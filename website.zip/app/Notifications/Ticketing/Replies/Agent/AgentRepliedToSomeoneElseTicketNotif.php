<?php

namespace App\Notifications\Ticketing\Replies\Agent;

use App\Notifications\Ticketing\Replies\NewReplyCreatedNotif;

class AgentRepliedToSomeoneElseTicketNotif extends NewReplyCreatedNotif
{
    public const NOTIF_ID = '09';
}
