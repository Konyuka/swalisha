<?php

namespace App\Notifications\Ticketing\Assigned;

class TicketAssignedNotMeNotif extends TicketAssignedNotif
{
    public const NOTIF_ID = '03';
}
