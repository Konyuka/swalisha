<?php

namespace App\Http\Middleware;

use Common\Core\BaseTrustHosts;

class TrustHosts extends BaseTrustHosts
{
    //
}
