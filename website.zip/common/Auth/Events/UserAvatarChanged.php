<?php

namespace Common\Auth\Events;

use App\Models\User;

class UserAvatarChanged
{
    /**
     * @var User
     */
    public $user;

    /**
     * @param User $user
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }
}
